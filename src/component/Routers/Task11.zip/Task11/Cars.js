import React from 'react'
import CarsProduct from './CarsProduct'
import content from './temp'
export default function Cars() {
return(
<>
<CarsProduct data={content} />
  
</>   
)
}
