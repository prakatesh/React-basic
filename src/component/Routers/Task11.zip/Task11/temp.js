import audi from './Images/audi.jpg'
import benz from "./Images/benz.jpg"
import swift from "./Images/swift.jpg"
import i20 from "./Images/i20.jpg"
const content=[
    {
        name:"audi",
        price:10000,
        img:audi
    },
    {
        name:"benz",
        price:1500,
        img:benz
    },
    {
        name:"swift",
        price:2500,
        img:swift
    },
    {
        name:"i20",
        price:3500,
        img:i20
    },
    {
        name:"audi",
        price:4500,
        img:audi
    },
    {
        name:"benz",
        price:5500,
        img:benz
    },
    {
        name:"swift",
        price:6500,
        img:swift
    },
    {
        name:"i20",
        price:7500,
        img:i20
    },
    {
        name:"audi",
        price:7500,
        img:audi
    }
]
export default content