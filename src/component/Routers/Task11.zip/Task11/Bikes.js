import React from 'react'

function Bikes() {
  return (
    <div>
      bikes
    </div>
  )
}

export default Bikes
